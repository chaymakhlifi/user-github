package fr.canalplus.calculette;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCalculetteApplicationTests {

    @Test
    void contextLoads() {
    }

}
