* Install Java 1.8.x 
* Install Git: https://git-scm.com/
* Install maven : download the 3.5.0 version (do not use the 3.5.3)
* Update maven configuration (conf to use proxy)

Use
-----------

* IntelliJ
    * Configure maven to use your maven installation and its settings.xml
    * Install lombok plugin
    * Configure automatic annotation
    * Import "unibet-live-test" project from File -> New -> Project from Existing Sources...
    * Configure Maven command "clean install" and launch it
   
* Eclipse
    * Configure eclipse to use your jdk installation
    * Configure maven to use your maven installation and its settings.xml
    * Install lombok (lombok version in the parent pom.xml)
        * find lombok into you maven repository: .m2\repository\org\projectlombok\lombok\1.16.10
        * execute lombok jar and patch your eclipse installation: java -jar lombok-1.16.10.jar
    * Configure annotation processing
        * from eclipse marketplace install the following plugin:  m2e-apt
        * from eclipse preference find 'maven annotation' and check 'Automatically checj JDT APT'
    * Import the project as a maven project
    * Configure Maven command "clean install" and launch it
  
Postman
-----------
* The Postam Project contains call to the REST services that we are exposing in this project
------

In file application.properties add value of param 
- parameter.timer.cron.payer=0/5 * * * * *
