package com.kindredgroup.unibetlivetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnibetLiveTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
