package com.kindredgroup.unibetlivetest.service;


import com.kindredgroup.unibetlivetest.dto.BetDto;

public interface BetSetvice {
	
	public void bet(BetDto bet);

}
