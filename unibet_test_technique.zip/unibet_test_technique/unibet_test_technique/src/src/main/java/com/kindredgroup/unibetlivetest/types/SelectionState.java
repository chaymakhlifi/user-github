package com.kindredgroup.unibetlivetest.types;

public enum SelectionState {
    OPENED,
    CLOSED,

}
