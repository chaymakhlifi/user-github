package com.kindredgroup.unibetlivetest.types;

public enum BetState {
    WON,
    LOST,
}
